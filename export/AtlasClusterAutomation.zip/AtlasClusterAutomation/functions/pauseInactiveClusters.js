/*
 * Iterates over the organizations projects and clusters, 
 * pausing clusters inactive for the configured minutes.
 */
exports = async function() {
  
  minutesInactive = 60;
  
  /*
   * These project names are just an example. 
   * The same concept could be used to exclude clusters or even 
   * configure different inactivity intervals by project or cluster.
   * These configuration options could also be stored and read from 
   * and Atlas database.
   */
  excludeProjects = ['PROD1', 'PROD2'];   
  
  const projects = await context.functions.execute("getProjects");
  
  projects.forEach(async project => {
    
    if (excludeProjects.includes(project.name)) {
      console.log(`Project '${project.name}' has been excluded from pause.`)
    } else {
      
      console.log(`Checking project '${project.name}'s clusters for inactivity...`);

      const clusters = await context.functions.execute("getProjectClusters", project.id);
      
      clusters.forEach(async cluster => {
        
        if (cluster.providerSettings.providerName != "TENANT") {   // It's a dedicated cluster than can be paused
        
          if (cluster.paused == false) {
        
            is_active =  await context.functions.execute("clusterIsActive", project.id, cluster.name, minutesInactive);
            
            if (!is_active) {
              console.log(`Pausing ${project.name}:${cluster.name} because it has been inactive for more then ${minutesInactive} minutes`);  
              //await context.functions.execute("pauseCluster", project.id, cluster.name, pause);
            } else {
              console.log(`Skipping pause for ${project.name}:${cluster.name} because it has active database users in the last ${minutesInactive} minutes.`);
            }
          }
        }
      });
     }
    });

  return true;
};