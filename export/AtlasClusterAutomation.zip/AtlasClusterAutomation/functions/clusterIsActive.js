/*
 * Used the database access history to determine if the cluster is in active use.
 * See https://docs.atlas.mongodb.com/reference/api/access-tracking-get-database-history-clustername/
 * 
 * Returns true (active) or false (inactive)
 * 
 */
exports = async function(project_id, clusterName, minutes) {
  
  if (project_id == 'Hello world!') { // We're testing from the console
    project_id = "5e8f8268d896f55ac04969a1";
    clusterName = "SA-SHARED-DEMO";
    minutes = 60;
  } /*else {
    console.log (`project_id: ${project_id}, clusterName: ${clusterName}, minutes: ${minutes}`)
  }*/
  
  // Get stored credentials...
  const username = await context.values.get("AtlasPublicKey");
  const password = await context.values.get("AtlasPrivateKey");
  
  const arg = { 
    scheme: 'https', 
    host: 'cloud.mongodb.com', 
    path: `api/atlas/v1.0/groups/${project_id}/dbAccessHistory/clusters/${clusterName}`, 
    //query: {'authResult': "true"},
    username: username, 
    password: password,
    headers: {'Content-Type': ['application/json'], 'Accept-Encoding': ['bzip, deflate']}, 
    digestAuth:true,
  };
  
  // The response body is a BSON.Binary object. Parse it and return.
  response = await context.http.get(arg);
  
  accessLogs = EJSON.parse(response.body.text()).accessLogs; 

  now = Date.now();
  const MS_PER_MINUTE = 60000;
  var durationInMinutes = (minutes < 30, 30, minutes);   // The log granularity is 30 minutes.
  var idleStartTime = now - (durationInMinutes * MS_PER_MINUTE);
  
  nowString = new Date(now).toString();
  idleStartTimeString = new Date(idleStartTime).toString();
  console.log(`Checking if cluster '${clusterName}' has been active in the last ${durationInMinutes} minutes`)
  console.log(`   ${nowString} - job is being run`);
  console.log(`   ${idleStartTimeString} - cluster inactivity before this time will be reported inactive`);
  
  clusterIsActive = false;
  
  accessLogs.every(log => {
    if (log.username != 'mms-automation' && log.username != 'mms-monitoring-agent') {
      
      // Convert string log date to milliseconds 
      logTime = Date.parse(log.timestamp);

      logTimeString = new Date(logTime);
      console.log(`   ${logTimeString} - last logged database access`);
      
      var elapsedTimeMins = Math.round((now - logTime)/MS_PER_MINUTE, 0);
      
      if (logTime > idleStartTime ) {
        console.log(`Cluster is Active: Username '${log.username}' was active in cluster '${clusterName}' ${elapsedTimeMins} minutes ago.`);
        clusterIsActive = true;
        return false;
      } else {
        // The first log entry is older than our inactive window
        console.log(`Cluster is Inactive: Username '${log.username}' was active in cluster '${clusterName}' ${elapsedTimeMins} minutes ago.`);
        clusterIsActive = false;
        return false;
      }
    }
    return true;

  });

  return clusterIsActive;

};

